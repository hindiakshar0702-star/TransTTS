import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const geist = Geist({ 
  subsets: ["latin"],
  variable: '--font-geist-sans'
});

const geistMono = Geist_Mono({ 
  subsets: ["latin"],
  variable: '--font-geist-mono'
});

export const metadata: Metadata = {
  title: 'TransTTS - AI Voice Generation Platform',
  description: 'Transform text into human-like AI voices with advanced voice cloning, multi-language TTS, and emotion control. The future of voice generation is here.',
  keywords: ['AI voice', 'text to speech', 'voice cloning', 'TTS', 'voice generation', 'AI audio'],
  authors: [{ name: 'TransTTS' }],
  openGraph: {
    title: 'TransTTS - AI Voice Generation Platform',
    description: 'Transform text into human-like AI voices with advanced voice cloning and multi-language support.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TransTTS - AI Voice Generation Platform',
    description: 'Transform text into human-like AI voices with advanced voice cloning.',
  },
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#1a0a2e',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geist.variable} ${geistMono.variable} bg-background`}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
