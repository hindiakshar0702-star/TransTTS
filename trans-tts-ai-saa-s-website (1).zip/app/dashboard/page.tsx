"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import { Sparkles, AudioWaveform, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { UploadWorkspace } from "@/components/dashboard/upload-workspace"
import { LanguageSelector } from "@/components/dashboard/language-selector"
import { AIProcessingSection } from "@/components/dashboard/ai-processing-section"
import { TranscriptionOutput } from "@/components/dashboard/transcription-output"
import { ExportOptions } from "@/components/dashboard/export-options"
import { AIFeaturesGrid } from "@/components/dashboard/ai-features-grid"
import { AnalyticsWidgets } from "@/components/dashboard/analytics-widgets"

type ProcessingStage = "idle" | "uploading" | "analyzing" | "transcribing" | "complete"

export default function DashboardPage() {
  const [selectedLanguage, setSelectedLanguage] = useState("auto")
  const [selectedFormat, setSelectedFormat] = useState("txt")
  const [enabledFeatures, setEnabledFeatures] = useState([
    "speaker",
    "noise",
    "subtitles",
    "multilang",
    "formatting",
  ])
  const [processingStatus, setProcessingStatus] = useState<{
    stage: ProcessingStage
    progress: number
    currentSpeaker?: number
    timestamp?: string
  }>({
    stage: "idle",
    progress: 0,
  })
  const [hasFile, setHasFile] = useState(false)

  const handleFileUpload = (file: File) => {
    setHasFile(true)
  }

  const handleToggleFeature = (id: string) => {
    setEnabledFeatures((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    )
  }

  const startTranscription = () => {
    setProcessingStatus({ stage: "analyzing", progress: 0 })

    // Simulate processing stages
    setTimeout(() => {
      setProcessingStatus({
        stage: "analyzing",
        progress: 30,
        currentSpeaker: 2,
      })
    }, 1500)

    setTimeout(() => {
      setProcessingStatus({
        stage: "transcribing",
        progress: 60,
        currentSpeaker: 2,
        timestamp: "Enabled",
      })
    }, 3000)

    setTimeout(() => {
      setProcessingStatus({
        stage: "complete",
        progress: 100,
        currentSpeaker: 2,
        timestamp: "Enabled",
      })
    }, 5000)
  }

  return (
    <div className="min-h-screen">
      {/* Hero Header */}
      <section className="relative overflow-hidden py-12 md:py-16">
        {/* Background Effects */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute bottom-0 right-1/4 h-96 w-96 rounded-full bg-accent/20 blur-3xl" />
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 rounded-full glass-card px-4 py-2 text-sm text-muted-foreground mb-6">
              <Sparkles className="h-4 w-4 text-accent" />
              Powered by Whisper AI
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">
              AI Audio <span className="gradient-text">Transcription</span>
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              Convert audio and video into accurate text instantly using advanced AI.
              Support for 100+ languages with speaker detection.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Dashboard Content */}
      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Upload & Settings */}
            <div className="lg:col-span-1 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <UploadWorkspace onFileUpload={handleFileUpload} />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-card rounded-2xl p-6"
              >
                <LanguageSelector
                  selectedLanguage={selectedLanguage}
                  onLanguageChange={setSelectedLanguage}
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-card rounded-2xl p-6"
              >
                <AIFeaturesGrid
                  enabledFeatures={enabledFeatures}
                  onToggleFeature={handleToggleFeature}
                />
              </motion.div>

              {/* Start Transcription Button */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Button
                  onClick={startTranscription}
                  disabled={!hasFile || processingStatus.stage !== "idle" && processingStatus.stage !== "complete"}
                  className="w-full py-6 text-lg font-semibold bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 neon-glow-purple disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {processingStatus.stage === "idle" || processingStatus.stage === "complete" ? (
                    <>
                      <Play className="mr-2 h-5 w-5" />
                      Start Transcription
                    </>
                  ) : (
                    <>
                      <AudioWaveform className="mr-2 h-5 w-5 animate-pulse" />
                      Processing...
                    </>
                  )}
                </Button>
              </motion.div>
            </div>

            {/* Right Column - Processing & Output */}
            <div className="lg:col-span-2 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-card rounded-2xl p-6"
              >
                <AIProcessingSection status={processingStatus} />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
              >
                <TranscriptionOutput
                  isProcessing={
                    processingStatus.stage === "transcribing" ||
                    processingStatus.stage === "analyzing"
                  }
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="glass-card rounded-2xl p-6"
              >
                <ExportOptions
                  selectedFormat={selectedFormat}
                  onFormatSelect={setSelectedFormat}
                />
              </motion.div>
            </div>
          </div>

          {/* Analytics Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12"
          >
            <h2 className="text-2xl font-bold text-foreground mb-6">
              Analytics Overview
            </h2>
            <AnalyticsWidgets />
          </motion.div>
        </div>
      </section>
    </div>
  )
}
