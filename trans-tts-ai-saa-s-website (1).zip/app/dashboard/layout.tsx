"use client"

import { DashboardNavbar } from "@/components/dashboard/dashboard-navbar"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-background">
      <DashboardNavbar />
      <main className="pt-20">{children}</main>
    </div>
  )
}
