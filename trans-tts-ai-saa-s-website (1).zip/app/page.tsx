import { Navbar } from "@/components/landing/navbar"
import { HeroSection } from "@/components/landing/hero-section"
import { FeaturesSection } from "@/components/landing/features-section"
import { LanguagesSection } from "@/components/landing/languages-section"
import { VoiceCloningSection } from "@/components/landing/voice-cloning-section"
import { DashboardPreviewSection } from "@/components/landing/dashboard-preview-section"
import { AudioWaveformSection } from "@/components/landing/audio-waveform-section"
import { PricingSection } from "@/components/landing/pricing-section"
import { TestimonialsSection } from "@/components/landing/testimonials-section"
import { FAQSection } from "@/components/landing/faq-section"
import { CTASection } from "@/components/landing/cta-section"
import { Footer } from "@/components/landing/footer"

export default function Home() {
  return (
    <main className="relative min-h-screen overflow-x-hidden">
      <Navbar />
      <HeroSection />
      <FeaturesSection />
      <LanguagesSection />
      <VoiceCloningSection />
      <DashboardPreviewSection />
      <AudioWaveformSection />
      <PricingSection />
      <TestimonialsSection />
      <FAQSection />
      <CTASection />
      <Footer />
    </main>
  )
}
