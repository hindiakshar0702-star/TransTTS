"use client"

import { motion } from "framer-motion"
import { Play, Pause, Volume2 } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

const audioSamples = [
  {
    name: "Sarah",
    description: "Natural female voice",
    language: "English (US)",
    text: "Welcome to TransTTS, where your words come to life with the power of artificial intelligence.",
  },
  {
    name: "James",
    description: "Professional male voice",
    language: "English (UK)",
    text: "Our advanced neural networks create voices that are indistinguishable from human speech.",
  },
  {
    name: "Emma",
    description: "Warm female voice",
    language: "English (AU)",
    text: "Transform any text into natural, expressive audio in seconds.",
  },
]

export function AudioWaveformSection() {
  const [activeVoice, setActiveVoice] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)

  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-accent/5 to-background" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 lg:mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Voice Preview
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-4">
            Hear the
            <span className="gradient-text"> Difference</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Experience the incredible quality of our AI-generated voices.
          </p>
        </motion.div>

        {/* Audio player */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto"
        >
          {/* Main player */}
          <div className="glass-card rounded-2xl p-6 sm:p-8 mb-6">
            {/* Voice info */}
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <span className="text-xl font-bold text-primary-foreground">
                  {audioSamples[activeVoice].name[0]}
                </span>
              </div>
              <div className="flex-1">
                <h4 className="font-semibold text-foreground">
                  {audioSamples[activeVoice].name}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {audioSamples[activeVoice].description} • {audioSamples[activeVoice].language}
                </p>
              </div>
              <Volume2 className="w-5 h-5 text-muted-foreground" />
            </div>

            {/* Text */}
            <div className="p-4 rounded-xl bg-secondary/50 border border-border mb-6">
              <p className="text-sm text-foreground leading-relaxed">
                {`"${audioSamples[activeVoice].text}"`}
              </p>
            </div>

            {/* Waveform visualization */}
            <div className="relative h-20 mb-6 flex items-center">
              <div className="absolute inset-0 flex items-end justify-center gap-[2px]">
                {Array.from({ length: 80 }).map((_, i) => {
                  const height = Math.sin((i / 80) * Math.PI * 3) * 50 + 50
                  return (
                    <motion.div
                      key={i}
                      className="w-1 rounded-full bg-gradient-to-t from-primary to-accent"
                      initial={{ height: "20%" }}
                      animate={{
                        height: isPlaying
                          ? [`${20 + height * 0.3}%`, `${20 + height * 0.8}%`, `${20 + height * 0.3}%`]
                          : `${20 + height * 0.5}%`,
                        opacity: isPlaying ? [0.5, 1, 0.5] : 0.7,
                      }}
                      transition={{
                        duration: isPlaying ? 0.6 : 0.3,
                        repeat: isPlaying ? Infinity : 0,
                        delay: i * 0.01,
                      }}
                    />
                  )
                })}
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">00:00</span>
              <Button
                size="lg"
                onClick={() => setIsPlaying(!isPlaying)}
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 neon-glow-purple"
              >
                {isPlaying ? (
                  <>
                    <Pause className="mr-2 h-5 w-5" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-5 w-5" />
                    Play Sample
                  </>
                )}
              </Button>
              <span className="text-sm text-muted-foreground">00:08</span>
            </div>
          </div>

          {/* Voice selector */}
          <div className="grid grid-cols-3 gap-4">
            {audioSamples.map((sample, index) => (
              <motion.button
                key={sample.name}
                onClick={() => {
                  setActiveVoice(index)
                  setIsPlaying(false)
                }}
                className={`p-4 rounded-xl border transition-all ${
                  activeVoice === index
                    ? "glass-card border-primary/50 bg-primary/10"
                    : "border-border bg-secondary/30 hover:bg-secondary/50"
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-2">
                  <span className="text-sm font-bold text-primary-foreground">
                    {sample.name[0]}
                  </span>
                </div>
                <p className="font-medium text-foreground text-sm">{sample.name}</p>
                <p className="text-xs text-muted-foreground">{sample.language}</p>
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
