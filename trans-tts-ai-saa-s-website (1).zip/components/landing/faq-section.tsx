"use client"

import { motion } from "framer-motion"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    question: "How does AI voice generation work?",
    answer: "Our AI uses advanced neural network models trained on thousands of hours of human speech. When you input text, the AI analyzes the content, applies natural language processing, and generates audio that mimics human speech patterns, intonation, and emotion.",
  },
  {
    question: "What languages are supported?",
    answer: "TransTTS supports over 50 languages including English, Spanish, French, German, Italian, Portuguese, Russian, Japanese, Korean, Chinese, Arabic, Hindi, and many more. Each language comes with multiple voice options and regional accents.",
  },
  {
    question: "How does voice cloning work?",
    answer: "Voice cloning requires just 30 seconds of clear audio. Our AI analyzes the unique characteristics of the voice - pitch, tone, cadence, and speech patterns - and creates a digital model that can generate new speech in that voice.",
  },
  {
    question: "Can I use the generated audio commercially?",
    answer: "Yes! All paid plans include a commercial license that allows you to use generated audio in videos, podcasts, advertisements, apps, and any other commercial content. The Free plan is limited to personal use only.",
  },
  {
    question: "What audio formats are supported?",
    answer: "We support MP3, WAV, and OGG formats. MP3 is available on all plans, while WAV and OGG are available on Pro and Enterprise plans. You can also choose from various sample rates and bitrates.",
  },
  {
    question: "Is there an API available?",
    answer: "Yes, we offer a comprehensive REST API with SDKs for Python, JavaScript, and other popular languages. The API supports real-time streaming, batch processing, and webhook notifications. Documentation is available at docs.transtts.com.",
  },
  {
    question: "How accurate is the emotion control?",
    answer: "Our emotion control feature allows you to adjust happiness, sadness, excitement, calm, and urgency levels. The AI applies these emotions naturally to the generated speech, making it more expressive and engaging.",
  },
  {
    question: "What happens if I exceed my character limit?",
    answer: "If you approach your monthly limit, we'll notify you via email. You can upgrade your plan at any time, and the new limits take effect immediately. Unused characters don't roll over to the next month.",
  },
]

export function FAQSection() {
  return (
    <section id="faq" className="relative py-24 lg:py-32">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />

      <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 lg:mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            FAQ
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-4">
            Frequently Asked
            <span className="gradient-text"> Questions</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about TransTTS.
          </p>
        </motion.div>

        {/* FAQ Accordion */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="glass-card rounded-xl px-6 border-none"
              >
                <AccordionTrigger className="text-left text-foreground hover:no-underline py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-12"
        >
          <p className="text-muted-foreground mb-4">
            {"Still have questions? We're here to help."}
          </p>
          <a
            href="mailto:support@transtts.com"
            className="text-primary hover:text-primary/80 font-medium transition-colors"
          >
            Contact Support →
          </a>
        </motion.div>
      </div>
    </section>
  )
}
