"use client"

import { motion } from "framer-motion"
import { 
  Mic, 
  Globe, 
  Smile, 
  Download, 
  Code, 
  Play, 
  Wand2, 
  Zap 
} from "lucide-react"

const features = [
  {
    icon: Mic,
    title: "AI Voice Generation",
    description: "Generate ultra-realistic voices from text with our state-of-the-art neural network models.",
    gradient: "from-primary to-accent",
  },
  {
    icon: Wand2,
    title: "Voice Cloning",
    description: "Clone any voice with just 30 seconds of audio. Create custom voices for your brand.",
    gradient: "from-accent to-primary",
  },
  {
    icon: Globe,
    title: "50+ Languages",
    description: "Generate voices in over 50 languages with native accents and natural pronunciation.",
    gradient: "from-primary to-accent",
  },
  {
    icon: Smile,
    title: "Emotion Control",
    description: "Add emotions like happiness, sadness, excitement, or calm to make voices more expressive.",
    gradient: "from-accent to-primary",
  },
  {
    icon: Download,
    title: "Audio Export",
    description: "Export high-quality audio in MP3, WAV, or OGG formats. Perfect for any project.",
    gradient: "from-primary to-accent",
  },
  {
    icon: Code,
    title: "API Integration",
    description: "Integrate voice generation into your apps with our simple REST API and SDKs.",
    gradient: "from-accent to-primary",
  },
  {
    icon: Play,
    title: "Real-time Preview",
    description: "Hear your generated voice instantly with our real-time streaming preview.",
    gradient: "from-primary to-accent",
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Generate voices in milliseconds. No waiting, no queues, instant results.",
    gradient: "from-accent to-primary",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
    },
  },
}

export function FeaturesSection() {
  return (
    <section id="features" className="relative py-24 lg:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Features
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-4">
            Everything You Need for
            <span className="gradient-text"> Voice Generation</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Powerful features designed for developers, content creators, and businesses 
            who need professional voice generation at scale.
          </p>
        </motion.div>

        {/* Features grid - Bento style */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              variants={itemVariants}
              className={`group relative overflow-hidden rounded-2xl glass-card p-6 transition-all duration-300 hover:-translate-y-1 ${
                index === 0 || index === 5 ? "sm:col-span-2" : ""
              }`}
            >
              {/* Hover glow effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-5`} />
              </div>

              <div className="relative">
                {/* Icon */}
                <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${feature.gradient}`}>
                  <feature.icon className="h-6 w-6 text-primary-foreground" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>

              {/* Border gradient on hover */}
              <div className={`absolute inset-0 rounded-2xl border border-transparent group-hover:border-primary/20 transition-colors duration-300`} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
