"use client"

import { motion } from "framer-motion"
import { WaveformVisualizerLarge } from "./waveform-visualizer"
import { Volume2, Settings, Clock, BarChart3 } from "lucide-react"

const dashboardStats = [
  { label: "Characters Used", value: "124,892", change: "+12%", icon: BarChart3 },
  { label: "Audio Generated", value: "8.4 hrs", change: "+8%", icon: Clock },
  { label: "Active Voices", value: "12", change: "+2", icon: Volume2 },
  { label: "API Calls", value: "1,234", change: "+24%", icon: Settings },
]

export function DashboardPreviewSection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[400px] h-[400px] rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 lg:mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
            Dashboard
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-4">
            Powerful Voice
            <span className="gradient-text"> Dashboard</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Monitor your usage, manage voices, and track performance all in one 
            beautiful, intuitive dashboard.
          </p>
        </motion.div>

        {/* Dashboard preview */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          {/* Glow effect */}
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 blur-2xl opacity-50" />

          {/* Main dashboard */}
          <div className="relative glass-card rounded-2xl overflow-hidden">
            {/* Dashboard header */}
            <div className="flex items-center justify-between p-4 sm:p-6 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <span className="text-sm text-muted-foreground hidden sm:block">
                  TransTTS Dashboard
                </span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent" />
              </div>
            </div>

            {/* Dashboard content */}
            <div className="p-4 sm:p-6">
              {/* Stats grid */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {dashboardStats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="p-4 rounded-xl bg-secondary/50 border border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <stat.icon className="w-4 h-4 text-muted-foreground" />
                      <span className="text-xs text-green-400">{stat.change}</span>
                    </div>
                    <p className="text-xl sm:text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
                  </motion.div>
                ))}
              </div>

              {/* Waveform section */}
              <div className="p-4 sm:p-6 rounded-xl bg-secondary/50 border border-border mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-semibold text-foreground">Recent Generation</h4>
                    <p className="text-xs text-muted-foreground">Voice: Sarah - Natural (EN)</p>
                  </div>
                  <span className="px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs">
                    Complete
                  </span>
                </div>
                <WaveformVisualizerLarge />
                <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
                  <span>00:00</span>
                  <span>Duration: 2:34</span>
                  <span>02:34</span>
                </div>
              </div>

              {/* Recent activity */}
              <div className="p-4 sm:p-6 rounded-xl bg-secondary/50 border border-border">
                <h4 className="font-semibold text-foreground mb-4">Recent Activity</h4>
                <div className="space-y-3">
                  {[
                    { voice: "Sarah", text: "Welcome to our platform...", time: "2 min ago" },
                    { voice: "James", text: "Thank you for your purchase...", time: "15 min ago" },
                    { voice: "Emma", text: "Your order has been shipped...", time: "1 hour ago" },
                  ].map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-4 p-3 rounded-lg bg-background/50 hover:bg-background/80 transition-colors"
                    >
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-primary-foreground">
                          {activity.voice[0]}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {activity.text}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Voice: {activity.voice}
                        </p>
                      </div>
                      <span className="text-xs text-muted-foreground flex-shrink-0">
                        {activity.time}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
