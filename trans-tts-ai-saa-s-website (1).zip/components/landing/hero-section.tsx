"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Play, Sparkles } from "lucide-react"
import { WaveformVisualizer } from "./waveform-visualizer"
import { FloatingParticles } from "./floating-particles"

export function HeroSection() {
  return (
    <section className="relative min-h-screen overflow-hidden pt-32 pb-20">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Primary gradient orb */}
        <div className="absolute -top-1/2 left-1/2 h-[800px] w-[800px] -translate-x-1/2 rounded-full bg-gradient-to-br from-primary/30 to-transparent blur-3xl animate-pulse-glow" />
        {/* Secondary gradient orb */}
        <div className="absolute top-1/4 -right-1/4 h-[600px] w-[600px] rounded-full bg-gradient-to-bl from-accent/20 to-transparent blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
        {/* Floating particles */}
        <FloatingParticles />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2 text-sm text-primary"
            >
              <Sparkles className="h-4 w-4" />
              <span>Powered by Advanced AI</span>
            </motion.div>

            {/* Headline */}
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl xl:text-7xl">
              <span className="text-foreground">Transform Text Into</span>
              <br />
              <span className="gradient-text">Human-Like AI Voices</span>
            </h1>

            {/* Subheadline */}
            <p className="mt-6 text-lg text-muted-foreground sm:text-xl max-w-xl mx-auto lg:mx-0">
              Generate ultra-realistic voices in 50+ languages with emotion control, 
              voice cloning, and seamless API integration. The future of voice is here.
            </p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="mt-10 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 neon-glow-purple text-lg px-8 py-6"
              >
                Start Free
                <Sparkles className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-border text-foreground hover:bg-secondary text-lg px-8 py-6"
              >
                <Play className="mr-2 h-5 w-5" />
                Generate Voice
              </Button>
            </motion.div>

            {/* Trust indicators */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="mt-12 flex flex-wrap items-center justify-center lg:justify-start gap-8 text-sm text-muted-foreground"
            >
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-green-500" />
                <span>No credit card required</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <span>10,000 free characters</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-accent" />
                <span>Cancel anytime</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Hero Visual - Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative"
          >
            <div className="relative animate-float">
              {/* Glowing border effect */}
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-primary via-accent to-primary opacity-30 blur-lg" />
              
              {/* Dashboard card */}
              <div className="relative glass-card rounded-2xl p-6 sm:p-8">
                {/* Dashboard header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="h-3 w-3 rounded-full bg-red-500" />
                    <div className="h-3 w-3 rounded-full bg-yellow-500" />
                    <div className="h-3 w-3 rounded-full bg-green-500" />
                  </div>
                  <span className="text-xs text-muted-foreground">TransTTS Studio</span>
                </div>

                {/* Voice selection */}
                <div className="mb-6 p-4 rounded-xl bg-secondary/50 border border-border">
                  <p className="text-xs text-muted-foreground mb-2">Selected Voice</p>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                      <span className="text-sm font-bold text-primary-foreground">AI</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Sarah - Natural</p>
                      <p className="text-xs text-muted-foreground">English (US) • Female</p>
                    </div>
                  </div>
                </div>

                {/* Text input area */}
                <div className="mb-6 p-4 rounded-xl bg-secondary/50 border border-border">
                  <p className="text-xs text-muted-foreground mb-2">Enter your text</p>
                  <p className="text-sm text-foreground leading-relaxed">
                    {"Welcome to TransTTS, where your words come alive with the power of artificial intelligence..."}
                  </p>
                </div>

                {/* Waveform */}
                <div className="mb-6">
                  <WaveformVisualizer />
                </div>

                {/* Generate button */}
                <Button className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground">
                  <Play className="mr-2 h-4 w-4" />
                  Generate Voice
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
