"use client"

import { motion } from "framer-motion"

export function WaveformVisualizer() {
  const bars = 40

  return (
    <div className="flex h-16 items-end justify-center gap-[2px]">
      {Array.from({ length: bars }).map((_, i) => {
        const delay = i * 0.05
        const height = Math.sin((i / bars) * Math.PI) * 100

        return (
          <motion.div
            key={i}
            className="w-1 rounded-full bg-gradient-to-t from-primary to-accent"
            initial={{ height: "20%" }}
            animate={{
              height: [`${20 + height * 0.3}%`, `${20 + height * 0.8}%`, `${20 + height * 0.3}%`],
            }}
            transition={{
              duration: 0.8,
              repeat: Infinity,
              delay: delay,
              ease: "easeInOut",
            }}
          />
        )
      })}
    </div>
  )
}

export function WaveformVisualizerLarge() {
  const bars = 60

  return (
    <div className="flex h-32 items-end justify-center gap-1">
      {Array.from({ length: bars }).map((_, i) => {
        const delay = i * 0.03
        const height = Math.sin((i / bars) * Math.PI) * 100

        return (
          <motion.div
            key={i}
            className="w-1.5 rounded-full bg-gradient-to-t from-primary via-accent to-primary"
            initial={{ height: "10%" }}
            animate={{
              height: [`${10 + height * 0.2}%`, `${10 + height * 0.9}%`, `${10 + height * 0.2}%`],
            }}
            transition={{
              duration: 1.2,
              repeat: Infinity,
              delay: delay,
              ease: "easeInOut",
            }}
          />
        )
      })}
    </div>
  )
}
