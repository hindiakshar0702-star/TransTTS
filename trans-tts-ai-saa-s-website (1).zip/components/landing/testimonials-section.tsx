"use client"

import { motion } from "framer-motion"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Chen",
    role: "Content Creator",
    company: "TechTube",
    content: "TransTTS has completely transformed my workflow. I can now produce voiceovers for my videos in minutes instead of hours. The voice quality is indistinguishable from real human voices.",
    rating: 5,
  },
  {
    name: "Michael Roberts",
    role: "Product Manager",
    company: "AudioBook Pro",
    content: "We switched from hiring voice actors to using TransTTS for our audiobook previews. The cost savings are incredible, and our customers love the variety of voices available.",
    rating: 5,
  },
  {
    name: "Emily Watson",
    role: "Marketing Director",
    company: "GlobalBrand Inc",
    content: "The multi-language support is a game-changer for our international campaigns. We can now localize our video content in 20+ languages with authentic-sounding voices.",
    rating: 5,
  },
  {
    name: "David Kim",
    role: "Lead Developer",
    company: "AppStudio",
    content: "The API is incredibly well-documented and easy to integrate. We had voice generation working in our app within a few hours. The streaming feature is fantastic.",
    rating: 5,
  },
  {
    name: "Lisa Thompson",
    role: "E-Learning Director",
    company: "EduTech Solutions",
    content: "Our students respond much better to the natural-sounding voices from TransTTS compared to our old robotic TTS system. Engagement has increased by 40%.",
    rating: 5,
  },
  {
    name: "James Martinez",
    role: "Podcast Host",
    company: "The Daily Brief",
    content: "Voice cloning is incredible. I recorded 30 seconds, and now I can generate podcast intros in my own voice whenever I need them. Total game-changer.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background effect */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-0 w-[400px] h-[400px] rounded-full bg-primary/10 blur-3xl -translate-y-1/2" />
        <div className="absolute top-1/2 right-0 w-[400px] h-[400px] rounded-full bg-accent/10 blur-3xl -translate-y-1/2" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 lg:mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-4">
            Loved by
            <span className="gradient-text"> Thousands</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            See what content creators, developers, and businesses are saying about TransTTS.
          </p>
        </motion.div>

        {/* Testimonials grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-card rounded-2xl p-6 hover:-translate-y-1 transition-transform duration-300"
            >
              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-yellow-500 text-yellow-500"
                  />
                ))}
              </div>

              {/* Content */}
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                {`"${testimonial.content}"`}
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <span className="text-sm font-bold text-primary-foreground">
                    {testimonial.name.split(" ").map(n => n[0]).join("")}
                  </span>
                </div>
                <div>
                  <p className="font-medium text-foreground text-sm">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.role} at {testimonial.company}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
