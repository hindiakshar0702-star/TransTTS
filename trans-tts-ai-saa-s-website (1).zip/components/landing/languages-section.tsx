"use client"

import { motion } from "framer-motion"
import { Globe } from "lucide-react"

const languages = [
  { code: "EN", name: "English", flag: "🇺🇸" },
  { code: "ES", name: "Spanish", flag: "🇪🇸" },
  { code: "FR", name: "French", flag: "🇫🇷" },
  { code: "DE", name: "German", flag: "🇩🇪" },
  { code: "IT", name: "Italian", flag: "🇮🇹" },
  { code: "PT", name: "Portuguese", flag: "🇵🇹" },
  { code: "RU", name: "Russian", flag: "🇷🇺" },
  { code: "JA", name: "Japanese", flag: "🇯🇵" },
  { code: "KO", name: "Korean", flag: "🇰🇷" },
  { code: "ZH", name: "Chinese", flag: "🇨🇳" },
  { code: "AR", name: "Arabic", flag: "🇸🇦" },
  { code: "HI", name: "Hindi", flag: "🇮🇳" },
]

const stats = [
  { value: "50+", label: "Languages" },
  { value: "200+", label: "Voice Models" },
  { value: "99.9%", label: "Accuracy" },
  { value: "24/7", label: "Availability" },
]

export function LanguagesSection() {
  return (
    <section id="languages" className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background effect */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
              Multi-Language Support
            </span>
            <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-6">
              Speak Every Language
              <span className="gradient-text"> Naturally</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Generate voices in over 50 languages with authentic accents and 
              natural pronunciation. Perfect for global content creation, 
              localization, and reaching audiences worldwide.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-2xl sm:text-3xl font-bold gradient-text">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Language globe visualization */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            {/* Central globe */}
            <div className="relative mx-auto w-64 h-64 sm:w-80 sm:h-80">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 animate-pulse-glow" />
              <div className="absolute inset-4 rounded-full bg-gradient-to-br from-secondary to-background border border-border flex items-center justify-center">
                <Globe className="w-24 h-24 sm:w-32 sm:h-32 text-primary/50" />
              </div>
            </div>

            {/* Orbiting languages */}
            <div className="absolute inset-0">
              {languages.map((lang, index) => {
                const angle = (index / languages.length) * 2 * Math.PI
                const radius = 140
                const x = Math.cos(angle) * radius
                const y = Math.sin(angle) * radius

                return (
                  <motion.div
                    key={lang.code}
                    className="absolute left-1/2 top-1/2"
                    style={{
                      x: x - 24,
                      y: y - 24,
                    }}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                  >
                    <motion.div
                      className="glass-card w-12 h-12 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform"
                      whileHover={{ scale: 1.1 }}
                      title={lang.name}
                    >
                      <span className="text-lg">{lang.flag}</span>
                    </motion.div>
                  </motion.div>
                )
              })}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
