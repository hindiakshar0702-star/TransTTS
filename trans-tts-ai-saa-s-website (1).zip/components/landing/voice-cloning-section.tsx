"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Upload, Mic, Play, Check } from "lucide-react"

const steps = [
  {
    icon: Upload,
    title: "Upload Audio",
    description: "Upload just 30 seconds of voice audio",
  },
  {
    icon: Mic,
    title: "AI Processing",
    description: "Our AI analyzes and learns the voice pattern",
  },
  {
    icon: Play,
    title: "Generate",
    description: "Create unlimited content with the cloned voice",
  },
]

const benefits = [
  "Perfect for brand voices",
  "Preserves natural tone",
  "Supports multiple languages",
  "Commercial use ready",
]

export function VoiceCloningSection() {
  return (
    <section id="voice-cloning" className="relative py-24 lg:py-32">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Demo card */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative order-2 lg:order-1"
          >
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-primary/30 via-accent/30 to-primary/30 blur-xl opacity-50" />
              
              {/* Main card */}
              <div className="relative glass-card rounded-2xl p-6 sm:p-8">
                <div className="flex items-center justify-between mb-6">
                  <h4 className="font-semibold text-foreground">Voice Cloning Studio</h4>
                  <span className="px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs">
                    Live
                  </span>
                </div>

                {/* Steps */}
                <div className="space-y-4 mb-6">
                  {steps.map((step, index) => (
                    <motion.div
                      key={step.title}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="flex items-center gap-4 p-4 rounded-xl bg-secondary/50 border border-border"
                    >
                      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <step.icon className="w-5 h-5 text-primary-foreground" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground text-sm">{step.title}</p>
                        <p className="text-xs text-muted-foreground">{step.description}</p>
                      </div>
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center">
                        <Check className="w-4 h-4 text-green-400" />
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Waveform visualization */}
                <div className="p-4 rounded-xl bg-secondary/50 border border-border mb-6">
                  <div className="flex items-end justify-center gap-1 h-16">
                    {Array.from({ length: 30 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="w-1 rounded-full bg-gradient-to-t from-primary to-accent"
                        animate={{
                          height: [`${20 + Math.random() * 60}%`, `${20 + Math.random() * 60}%`],
                        }}
                        transition={{
                          duration: 0.5,
                          repeat: Infinity,
                          repeatType: "reverse",
                          delay: i * 0.02,
                        }}
                      />
                    ))}
                  </div>
                  <p className="text-center text-xs text-muted-foreground mt-3">
                    Voice pattern analyzed successfully
                  </p>
                </div>

                <Button className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground">
                  Clone Your Voice
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-1 lg:order-2"
          >
            <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              Voice Cloning
            </span>
            <h2 className="text-3xl font-bold sm:text-4xl lg:text-5xl text-foreground mb-6">
              Clone Any Voice in
              <span className="gradient-text"> 30 Seconds</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Create a perfect digital replica of any voice with just a short audio 
              sample. Our advanced AI captures the unique characteristics, tone, and 
              style of any voice for unlimited content creation.
            </p>

            {/* Benefits */}
            <ul className="space-y-3 mb-8">
              {benefits.map((benefit, index) => (
                <motion.li
                  key={benefit}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="w-5 h-5 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-primary-foreground" />
                  </div>
                  <span className="text-foreground">{benefit}</span>
                </motion.li>
              ))}
            </ul>

            <Button
              size="lg"
              className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90"
            >
              Try Voice Cloning Free
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
