"use client"

import { motion } from "framer-motion"
import { FileText, FileType, File, Subtitles, Captions } from "lucide-react"

const exportOptions = [
  {
    id: "txt",
    name: "TXT",
    description: "Plain text",
    icon: FileText,
  },
  {
    id: "docx",
    name: "DOCX",
    description: "Word document",
    icon: FileType,
  },
  {
    id: "pdf",
    name: "PDF",
    description: "PDF document",
    icon: File,
  },
  {
    id: "srt",
    name: "SRT",
    description: "Subtitles",
    icon: Subtitles,
  },
  {
    id: "vtt",
    name: "VTT",
    description: "Web captions",
    icon: Captions,
  },
]

export function ExportOptions({
  selectedFormat,
  onFormatSelect,
}: {
  selectedFormat: string
  onFormatSelect: (format: string) => void
}) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-foreground">Export Format</h3>
      <div className="grid grid-cols-5 gap-3">
        {exportOptions.map((option) => {
          const Icon = option.icon
          const isSelected = selectedFormat === option.id
          return (
            <motion.button
              key={option.id}
              onClick={() => onFormatSelect(option.id)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`relative flex flex-col items-center gap-2 rounded-xl p-4 transition-all ${
                isSelected
                  ? "glass-card border-primary/50 neon-glow-purple"
                  : "bg-secondary/30 border border-border/30 hover:bg-secondary/50"
              }`}
            >
              {isSelected && (
                <motion.div
                  layoutId="selectedFormat"
                  className="absolute inset-0 rounded-xl border-2 border-primary/50"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
              <Icon
                className={`relative z-10 h-6 w-6 ${
                  isSelected ? "text-primary" : "text-muted-foreground"
                }`}
              />
              <div className="relative z-10 text-center">
                <p
                  className={`text-sm font-medium ${
                    isSelected ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {option.name}
                </p>
                <p className="text-xs text-muted-foreground">{option.description}</p>
              </div>
            </motion.button>
          )
        })}
      </div>
    </div>
  )
}
