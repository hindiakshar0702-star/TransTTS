"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { Search, Check, Globe, Sparkles } from "lucide-react"
import { Input } from "@/components/ui/input"

const languages = [
  { code: "auto", name: "Auto Detect", flag: "🌐" },
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Spanish", flag: "🇪🇸" },
  { code: "fr", name: "French", flag: "🇫🇷" },
  { code: "de", name: "German", flag: "🇩🇪" },
  { code: "it", name: "Italian", flag: "🇮🇹" },
  { code: "pt", name: "Portuguese", flag: "🇵🇹" },
  { code: "zh", name: "Chinese", flag: "🇨🇳" },
  { code: "ja", name: "Japanese", flag: "🇯🇵" },
  { code: "ko", name: "Korean", flag: "🇰🇷" },
  { code: "ar", name: "Arabic", flag: "🇸🇦" },
  { code: "hi", name: "Hindi", flag: "🇮🇳" },
  { code: "ru", name: "Russian", flag: "🇷🇺" },
  { code: "nl", name: "Dutch", flag: "🇳🇱" },
  { code: "tr", name: "Turkish", flag: "🇹🇷" },
  { code: "pl", name: "Polish", flag: "🇵🇱" },
]

const popularLanguages = ["en", "es", "fr", "de", "zh", "ja"]

export function LanguageSelector({
  selectedLanguage,
  onLanguageChange,
}: {
  selectedLanguage: string
  onLanguageChange: (code: string) => void
}) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isOpen, setIsOpen] = useState(false)

  const filteredLanguages = languages.filter((lang) =>
    lang.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const selectedLang = languages.find((l) => l.code === selectedLanguage)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
          <Globe className="h-4 w-4 text-primary" />
          Source Language
        </h3>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Sparkles className="h-3 w-3 text-accent" />
          AI Recommended
        </div>
      </div>

      {/* Popular Languages */}
      <div className="flex flex-wrap gap-2">
        {popularLanguages.map((code) => {
          const lang = languages.find((l) => l.code === code)
          if (!lang) return null
          const isSelected = selectedLanguage === code
          return (
            <motion.button
              key={code}
              onClick={() => onLanguageChange(code)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-sm transition-colors ${
                isSelected
                  ? "bg-gradient-to-r from-primary to-accent text-primary-foreground neon-glow-purple"
                  : "bg-secondary text-muted-foreground hover:bg-secondary/80"
              }`}
            >
              <span>{lang.flag}</span>
              <span>{lang.name}</span>
            </motion.button>
          )
        })}
      </div>

      {/* Dropdown */}
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between gap-3 glass-card rounded-xl px-4 py-3 text-left transition-colors hover:bg-secondary/50"
        >
          <div className="flex items-center gap-3">
            <span className="text-xl">{selectedLang?.flag}</span>
            <span className="font-medium text-foreground">{selectedLang?.name}</span>
          </div>
          <motion.svg
            animate={{ rotate: isOpen ? 180 : 0 }}
            className="h-5 w-5 text-muted-foreground"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </motion.svg>
        </button>

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-20 mt-2 w-full rounded-xl glass-card border border-border/50 p-2 shadow-xl"
          >
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search language..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 bg-secondary/50 border-border/50"
              />
            </div>
            <div className="max-h-48 overflow-y-auto space-y-1">
              {filteredLanguages.map((lang) => {
                const isSelected = selectedLanguage === lang.code
                return (
                  <button
                    key={lang.code}
                    onClick={() => {
                      onLanguageChange(lang.code)
                      setIsOpen(false)
                      setSearchQuery("")
                    }}
                    className={`w-full flex items-center justify-between gap-3 rounded-lg px-3 py-2 text-left transition-colors ${
                      isSelected
                        ? "bg-primary/20 text-foreground"
                        : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{lang.flag}</span>
                      <span>{lang.name}</span>
                    </div>
                    {isSelected && <Check className="h-4 w-4 text-primary" />}
                  </button>
                )
              })}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
