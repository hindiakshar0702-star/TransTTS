"use client"

import { motion } from "framer-motion"
import { Volume2, Users, Sparkles, Clock, AudioWaveform, Loader2 } from "lucide-react"

interface ProcessingStatus {
  stage: "idle" | "uploading" | "analyzing" | "transcribing" | "complete"
  progress: number
  currentSpeaker?: number
  noiseReduction?: boolean
  timestamp?: string
}

const stages = [
  { id: "analyzing", label: "AI Analyzing", icon: Sparkles },
  { id: "transcribing", label: "Transcribing", icon: AudioWaveform },
  { id: "complete", label: "Complete", icon: Volume2 },
]

export function AIProcessingSection({ status }: { status: ProcessingStatus }) {
  const isProcessing = status.stage !== "idle" && status.stage !== "complete"

  return (
    <div className="space-y-6">
      {/* Waveform Visualization */}
      <div className="relative rounded-xl glass-card p-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5" />
        <div className="relative">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-foreground flex items-center gap-2">
              <AudioWaveform className="h-4 w-4 text-primary" />
              Audio Waveform
            </h3>
            {isProcessing && (
              <span className="flex items-center gap-2 text-xs text-accent">
                <Loader2 className="h-3 w-3 animate-spin" />
                Processing...
              </span>
            )}
          </div>

          {/* Waveform Bars */}
          <div className="flex items-center justify-center gap-1 h-24">
            {Array.from({ length: 50 }).map((_, i) => (
              <motion.div
                key={i}
                className="w-1 rounded-full bg-gradient-to-t from-primary to-accent"
                animate={{
                  height: isProcessing
                    ? [
                        Math.random() * 60 + 20,
                        Math.random() * 80 + 16,
                        Math.random() * 40 + 30,
                      ]
                    : 16,
                  opacity: isProcessing ? 1 : 0.3,
                }}
                transition={{
                  duration: 0.5,
                  repeat: isProcessing ? Infinity : 0,
                  delay: i * 0.02,
                }}
                style={{ height: 16 }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Progress Indicators */}
      <div className="grid grid-cols-3 gap-3">
        {stages.map((stage, index) => {
          const Icon = stage.icon
          const isActive =
            status.stage === stage.id ||
            (status.stage === "transcribing" && stage.id === "analyzing")
          const isComplete =
            status.stage === "complete" ||
            (status.stage === "transcribing" && index === 0)

          return (
            <motion.div
              key={stage.id}
              className={`relative rounded-xl p-4 text-center transition-all ${
                isActive || isComplete
                  ? "glass-card border-primary/30"
                  : "bg-secondary/30 border border-border/30"
              }`}
              animate={{
                scale: isActive ? 1.02 : 1,
              }}
            >
              {isActive && !isComplete && (
                <motion.div
                  className="absolute inset-0 rounded-xl border border-primary/50"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              )}
              <Icon
                className={`mx-auto h-6 w-6 mb-2 ${
                  isComplete
                    ? "text-accent"
                    : isActive
                    ? "text-primary"
                    : "text-muted-foreground"
                }`}
              />
              <p
                className={`text-xs font-medium ${
                  isActive || isComplete
                    ? "text-foreground"
                    : "text-muted-foreground"
                }`}
              >
                {stage.label}
              </p>
              {isComplete && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-accent flex items-center justify-center"
                >
                  <svg
                    className="h-2.5 w-2.5 text-accent-foreground"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth={3}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M5 13l4 4L19 7"
                    />
                  </svg>
                </motion.div>
              )}
            </motion.div>
          )
        })}
      </div>

      {/* Status Indicators */}
      <div className="grid grid-cols-2 gap-3">
        <div className="glass-card rounded-xl p-4 flex items-center gap-3">
          <div
            className={`rounded-lg p-2 ${
              status.currentSpeaker ? "bg-primary/20" : "bg-secondary"
            }`}
          >
            <Users className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Speaker Detection</p>
            <p className="text-sm font-medium text-foreground">
              {status.currentSpeaker
                ? `${status.currentSpeaker} speaker(s)`
                : "Detecting..."}
            </p>
          </div>
        </div>
        <div className="glass-card rounded-xl p-4 flex items-center gap-3">
          <div
            className={`rounded-lg p-2 ${
              status.timestamp ? "bg-accent/20" : "bg-secondary"
            }`}
          >
            <Clock className="h-4 w-4 text-accent" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Timestamps</p>
            <p className="text-sm font-medium text-foreground">
              {status.timestamp || "Generating..."}
            </p>
          </div>
        </div>
      </div>

      {/* Main Progress Bar */}
      {isProcessing && (
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Transcription Progress</span>
            <span>{Math.round(status.progress)}%</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-secondary">
            <motion.div
              className="h-full bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_100%]"
              initial={{ width: 0 }}
              animate={{
                width: `${status.progress}%`,
                backgroundPosition: ["0% 0%", "100% 0%"],
              }}
              transition={{
                width: { duration: 0.5 },
                backgroundPosition: { duration: 2, repeat: Infinity },
              }}
            />
          </div>
        </div>
      )}
    </div>
  )
}
