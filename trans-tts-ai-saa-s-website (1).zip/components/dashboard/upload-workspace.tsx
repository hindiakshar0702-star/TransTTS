"use client"

import { motion, AnimatePresence } from "framer-motion"
import { useState, useCallback } from "react"
import {
  Upload,
  FileAudio,
  X,
  CloudIcon,
  HardDrive,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface UploadedFile {
  name: string
  size: number
  type: string
  progress: number
}

const supportedFormats = ["MP3", "WAV", "MP4", "MKV", "FLAC", "OGG", "WebM"]

export function UploadWorkspace({
  onFileUpload,
}: {
  onFileUpload: (file: File) => void
}) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null)
  const [isUploading, setIsUploading] = useState(false)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true)
    } else if (e.type === "dragleave") {
      setIsDragging(false)
    }
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
      setIsDragging(false)

      const files = e.dataTransfer.files
      if (files && files[0]) {
        handleFileSelect(files[0])
      }
    },
    []
  )

  const handleFileSelect = (file: File) => {
    setIsUploading(true)
    setUploadedFile({
      name: file.name,
      size: file.size,
      type: file.type,
      progress: 0,
    })

    // Simulate upload progress
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.random() * 30
      if (progress >= 100) {
        progress = 100
        clearInterval(interval)
        setIsUploading(false)
        onFileUpload(file)
      }
      setUploadedFile((prev) =>
        prev ? { ...prev, progress: Math.min(progress, 100) } : null
      )
    }, 200)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files[0]) {
      handleFileSelect(files[0])
    }
  }

  const removeFile = () => {
    setUploadedFile(null)
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <div className="space-y-4">
      {/* Upload Zone */}
      <motion.div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`relative rounded-2xl border-2 border-dashed transition-all duration-300 ${
          isDragging
            ? "border-primary bg-primary/10 neon-glow-purple"
            : "border-border hover:border-primary/50 hover:bg-secondary/30"
        }`}
      >
        <input
          type="file"
          accept="audio/*,video/*"
          onChange={handleInputChange}
          className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
        />
        <div className="flex flex-col items-center justify-center px-6 py-12 text-center">
          <motion.div
            animate={{
              y: isDragging ? -10 : 0,
              scale: isDragging ? 1.1 : 1,
            }}
            className="mb-4 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 p-4"
          >
            <Upload className="h-10 w-10 text-primary" />
          </motion.div>
          <h3 className="mb-2 text-lg font-semibold text-foreground">
            {isDragging ? "Drop your file here" : "Drag & drop your audio or video"}
          </h3>
          <p className="mb-4 text-sm text-muted-foreground">
            or click to browse from your device
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {supportedFormats.map((format) => (
              <span
                key={format}
                className="rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground"
              >
                {format}
              </span>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Integration Options */}
      <div className="flex flex-wrap gap-3">
        <Button variant="outline" className="gap-2 glass-card border-border/50">
          <HardDrive className="h-4 w-4" />
          Upload from Device
        </Button>
        <Button variant="outline" className="gap-2 glass-card border-border/50">
          <CloudIcon className="h-4 w-4" />
          Google Drive
        </Button>
        <Button variant="outline" className="gap-2 glass-card border-border/50">
          <CloudIcon className="h-4 w-4" />
          Dropbox
        </Button>
      </div>

      {/* Uploaded File */}
      <AnimatePresence>
        {uploadedFile && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="glass-card rounded-xl p-4"
          >
            <div className="flex items-center gap-4">
              <div className="rounded-xl bg-primary/20 p-3">
                <FileAudio className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="truncate font-medium text-foreground">
                  {uploadedFile.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {formatFileSize(uploadedFile.size)}
                </p>
              </div>
              {isUploading ? (
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
              ) : (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={removeFile}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="h-5 w-5" />
                </Button>
              )}
            </div>
            {isUploading && (
              <div className="mt-3">
                <div className="h-2 overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-accent"
                    initial={{ width: 0 }}
                    animate={{ width: `${uploadedFile.progress}%` }}
                  />
                </div>
                <p className="mt-1 text-xs text-muted-foreground text-right">
                  {Math.round(uploadedFile.progress)}%
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
