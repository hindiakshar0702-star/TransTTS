"use client"

import { motion } from "framer-motion"
import {
  Clock,
  FileText,
  Zap,
  TrendingUp,
  BarChart3,
  Download,
} from "lucide-react"

const stats = [
  {
    id: "duration",
    label: "Audio Duration",
    value: "4:32:18",
    change: "+12%",
    icon: Clock,
    color: "primary",
  },
  {
    id: "words",
    label: "Words Transcribed",
    value: "42,847",
    change: "+8%",
    icon: FileText,
    color: "accent",
  },
  {
    id: "accuracy",
    label: "AI Accuracy",
    value: "98.7%",
    change: "+2%",
    icon: Zap,
    color: "primary",
  },
  {
    id: "speed",
    label: "Processing Speed",
    value: "3.2x",
    change: "+15%",
    icon: TrendingUp,
    color: "accent",
  },
  {
    id: "usage",
    label: "Monthly Usage",
    value: "78%",
    change: "-5%",
    icon: BarChart3,
    color: "primary",
  },
  {
    id: "exports",
    label: "Total Exports",
    value: "156",
    change: "+23%",
    icon: Download,
    color: "accent",
  },
]

export function AnalyticsWidgets() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {stats.map((stat, index) => {
        const Icon = stat.icon
        const isPositive = stat.change.startsWith("+")
        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="glass-card rounded-xl p-4"
          >
            <div className="flex items-start justify-between mb-3">
              <div
                className={`rounded-lg p-2 ${
                  stat.color === "primary" ? "bg-primary/20" : "bg-accent/20"
                }`}
              >
                <Icon
                  className={`h-4 w-4 ${
                    stat.color === "primary" ? "text-primary" : "text-accent"
                  }`}
                />
              </div>
              <span
                className={`text-xs font-medium ${
                  isPositive ? "text-green-400" : "text-red-400"
                }`}
              >
                {stat.change}
              </span>
            </div>
            <motion.p
              className="text-2xl font-bold text-foreground mb-1"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: index * 0.1 + 0.2 }}
            >
              {stat.value}
            </motion.p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </motion.div>
        )
      })}
    </div>
  )
}
