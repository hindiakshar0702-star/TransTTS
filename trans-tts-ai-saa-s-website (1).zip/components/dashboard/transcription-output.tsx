"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import {
  Copy,
  Download,
  Share2,
  RefreshCw,
  Edit3,
  User,
  Clock,
  Check,
} from "lucide-react"
import { Button } from "@/components/ui/button"

interface TranscriptSegment {
  speaker: string
  timestamp: string
  text: string
  isActive?: boolean
}

const sampleTranscript: TranscriptSegment[] = [
  {
    speaker: "Speaker 1",
    timestamp: "00:00:00",
    text: "Welcome to TransTTS AI, the most advanced audio transcription platform powered by cutting-edge artificial intelligence.",
    isActive: true,
  },
  {
    speaker: "Speaker 1",
    timestamp: "00:00:08",
    text: "Our platform uses Whisper AI to deliver incredibly accurate transcriptions in over 100 languages.",
  },
  {
    speaker: "Speaker 2",
    timestamp: "00:00:15",
    text: "That sounds amazing! How accurate is the transcription compared to other services?",
  },
  {
    speaker: "Speaker 1",
    timestamp: "00:00:22",
    text: "We achieve up to 99% accuracy on clear audio. Our AI also handles background noise, multiple speakers, and various accents with remarkable precision.",
  },
  {
    speaker: "Speaker 2",
    timestamp: "00:00:35",
    text: "And what about export options? Can I download the transcript in different formats?",
  },
  {
    speaker: "Speaker 1",
    timestamp: "00:00:42",
    text: "Absolutely! You can export your transcripts as TXT, DOCX, PDF, or even subtitle formats like SRT and VTT for video content.",
  },
]

export function TranscriptionOutput({
  transcript = sampleTranscript,
  isProcessing = false,
}: {
  transcript?: TranscriptSegment[]
  isProcessing?: boolean
}) {
  const [isEditing, setIsEditing] = useState(false)
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    const text = transcript.map((s) => `[${s.timestamp}] ${s.speaker}: ${s.text}`).join("\n")
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Transcription Output</h3>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <Edit3 className="h-4 w-4" />
            {isEditing ? "Done" : "Edit"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCopy}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            {copied ? (
              <Check className="h-4 w-4 text-accent" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
            {copied ? "Copied!" : "Copy"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <Share2 className="h-4 w-4" />
            Share
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className="h-4 w-4" />
            Regenerate
          </Button>
        </div>
      </div>

      {/* Transcript Panel */}
      <div className="glass-card rounded-2xl overflow-hidden">
        <div className="max-h-[500px] overflow-y-auto p-6 space-y-4">
          {transcript.map((segment, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative rounded-xl p-4 transition-colors ${
                segment.isActive
                  ? "bg-primary/10 border border-primary/30"
                  : "bg-secondary/30 hover:bg-secondary/50"
              }`}
            >
              {segment.isActive && (
                <motion.div
                  className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-primary to-accent rounded-l-xl"
                  layoutId="activeIndicator"
                />
              )}
              <div className="flex items-start gap-3">
                <div
                  className={`rounded-lg p-2 ${
                    segment.speaker === "Speaker 1"
                      ? "bg-primary/20"
                      : "bg-accent/20"
                  }`}
                >
                  <User
                    className={`h-4 w-4 ${
                      segment.speaker === "Speaker 1"
                        ? "text-primary"
                        : "text-accent"
                    }`}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-foreground">
                      {segment.speaker}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {segment.timestamp}
                    </span>
                  </div>
                  {isEditing ? (
                    <textarea
                      defaultValue={segment.text}
                      className="w-full bg-transparent text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-primary rounded-lg p-2"
                      rows={2}
                    />
                  ) : (
                    <p
                      className={`text-sm leading-relaxed ${
                        segment.isActive
                          ? "text-foreground"
                          : "text-muted-foreground"
                      }`}
                    >
                      {segment.text}
                    </p>
                  )}
                </div>
              </div>
            </motion.div>
          ))}

          {isProcessing && (
            <motion.div
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="flex items-center gap-2 text-muted-foreground"
            >
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-primary animate-bounce" />
                <span
                  className="w-2 h-2 rounded-full bg-primary animate-bounce"
                  style={{ animationDelay: "0.1s" }}
                />
                <span
                  className="w-2 h-2 rounded-full bg-primary animate-bounce"
                  style={{ animationDelay: "0.2s" }}
                />
              </div>
              <span className="text-sm">Transcribing...</span>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}
