"use client"

import { motion } from "framer-motion"
import {
  Users,
  Volume2,
  Subtitles,
  FileText,
  Globe,
  Sparkles,
} from "lucide-react"

const features = [
  {
    id: "speaker",
    name: "Speaker Detection",
    description: "Identify multiple speakers",
    icon: Users,
    enabled: true,
  },
  {
    id: "noise",
    name: "Noise Removal",
    description: "Clean audio automatically",
    icon: Volume2,
    enabled: true,
  },
  {
    id: "subtitles",
    name: "Subtitle Generation",
    description: "Create SRT/VTT files",
    icon: Subtitles,
    enabled: true,
  },
  {
    id: "summary",
    name: "AI Summarization",
    description: "Generate content summary",
    icon: FileText,
    enabled: false,
  },
  {
    id: "multilang",
    name: "Multi-language",
    description: "100+ languages supported",
    icon: Globe,
    enabled: true,
  },
  {
    id: "formatting",
    name: "Smart Formatting",
    description: "Auto punctuation & caps",
    icon: Sparkles,
    enabled: true,
  },
]

export function AIFeaturesGrid({
  enabledFeatures,
  onToggleFeature,
}: {
  enabledFeatures: string[]
  onToggleFeature: (id: string) => void
}) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-foreground">AI Features</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {features.map((feature, index) => {
          const Icon = feature.icon
          const isEnabled = enabledFeatures.includes(feature.id)
          return (
            <motion.button
              key={feature.id}
              onClick={() => onToggleFeature(feature.id)}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`relative group rounded-xl p-4 text-left transition-all ${
                isEnabled
                  ? "glass-card border-primary/30"
                  : "bg-secondary/20 border border-border/30 hover:bg-secondary/40"
              }`}
            >
              {/* Gradient border effect */}
              {isEnabled && (
                <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 opacity-50" />
              )}
              
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-2">
                  <div
                    className={`rounded-lg p-2 ${
                      isEnabled ? "bg-primary/20" : "bg-secondary"
                    }`}
                  >
                    <Icon
                      className={`h-4 w-4 ${
                        isEnabled ? "text-primary" : "text-muted-foreground"
                      }`}
                    />
                  </div>
                  <div
                    className={`w-8 h-4 rounded-full transition-colors ${
                      isEnabled ? "bg-primary" : "bg-secondary"
                    }`}
                  >
                    <motion.div
                      className="w-3 h-3 rounded-full bg-foreground mt-0.5"
                      animate={{ x: isEnabled ? 18 : 2 }}
                      transition={{ type: "spring", bounce: 0.4 }}
                    />
                  </div>
                </div>
                <p
                  className={`text-sm font-medium mb-0.5 ${
                    isEnabled ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  {feature.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {feature.description}
                </p>
              </div>
            </motion.button>
          )
        })}
      </div>
    </div>
  )
}
